 <!-- -----1st--Navbar--------- -->
 <div class="container-fluid">
     <div class="container">
   
            <div class="row topnav-medulla">
                <div class="col-lg-4 col-md-0 col-0 no-display">
        
                </div>
                <div class="col-lg-4 col-md-6 col-6 oki">

                    <div class="mx-auto land_page_head d-flex">
                        <img src="{{ asset('user') }}/assets/images/final-logo.png" alt="w8" >
                     
                      </div>


                </div>
                <div class="col-lg-4 col-md-6 col-6 phone-colum" >
                    
             <div>
                 <p class="phone-num m-0 ">(305) 400-4033</p>

             </div>

                </div>
            </div>
             

       
     </div>
 </div>

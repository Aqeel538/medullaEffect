 <!-- -----1st--Navbar--------- -->
 <div class="container-fluid">
     <div class="container">
   
            <div class="row topnav-medulla">
                <div class="col-lg-4 col-md-0 col-0 no-display">
        
                </div>
                <div class="col-lg-4 col-md-6 col-6 oki">

                <div class="res-on-375  d-flex">

<img src="{{ asset('user/images') }}/job-search-company.png" alt="w8" style="font-weight: 700;">
&nbsp; <h4 class="Logo-text">Medulla
    Effects</h4>
</div>


                </div>
                <div class="col-lg-4 col-md-6 col-6 phone-colum" >
                    
             <div>
                 <p class="phone-num m-0 ">(305) 400-4033</p>

             </div>

                </div>
            </div>
             

       
     </div>
 </div>

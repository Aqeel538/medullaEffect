 <!-- -----1st--Navbar--------- -->
 <div class="container-fluid">
     <div class="container">
         <div
             class="topnav-medulla  mt-4 mb-4 justify-content-lg-center justify-content-md-center justify-content-between ">
             <div class="again_respons ">
                 <p style="visibility: hidden;">medula@gmail.com</p>
             </div>
             <div class="res-on-375 mx-lg-auto mx-md-auto  d-flex">

                 <img src="{{ asset('user/images') }}/job-search-company.png" alt="w8" style="font-weight: 700;">
                 &nbsp; <h4 class="Logo-text">Medulla
                     Effects</h4>
             </div>

             <div>
                 <p class="phone-num m-0 Logo-text">(305) 400-4033</p>

             </div>

         </div>
     </div>
 </div>

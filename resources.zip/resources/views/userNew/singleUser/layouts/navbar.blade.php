 <!-- -----1st--Navbar--------- -->
 <div class="container-fluid">
     <div class="container">
         <div class="d-flex justify-content-center align-items-center mt-4 mb-4">
             <div class="">
                 <a href="https://web.whatsapp.com/"> <img
                         src="{{ asset('user') }}/assets/images/landing-page-img/Vectorinsta.png" class="icon-img"
                         alt="" srcset="">&nbsp;</a>
                 <a href=""> <img src="{{ asset('user') }}/assets/images/landing-page-img/vecyoutube.png"
                         alt="" class="icon-img" srcset=""></a>


             </div>
             <div class="res-on-375 mx-auto  d-flex">

                 <img src="{{ asset('user/images') }}/job-search-company.png" alt="w8" style="font-weight: 700;">
                 &nbsp; <h4 class="Logo-text">Medulla
                     Effects</h4>
             </div>
             <div>
                 <a href="">
                     <img src="{{ asset('user') }}/assets/images/landing-page-img/Vectorphone.png" class="icon-img"
                         alt="" srcset=""> &nbsp;
                 </a>
                 <a href="">
                     <img src="{{ asset('user') }}/assets/images/landing-page-img/Vectorredemail.png" class="icon-img"
                         alt="" srcset="">
                 </a>


             </div>
         </div>
     </div>
 </div>

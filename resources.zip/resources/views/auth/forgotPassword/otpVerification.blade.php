@extends('userNew.singleUser.layouts.main2')
@section('content')
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-4 col-12 company_bg">
                <div class="d-flex justify-content-between">
                    <div>
                        <span><i class="ri-instagram-line text-white Remix_icon"></i></span>
                        <span><i class="ri-youtube-line ms-1 text-white Remix_icon"></i>
                        </span>
                    </div>
                    <div>
                        <span><i class="fa-solid fa-phone text-white phara_16"></i></span>
                        <span><i class="fa-regular fa-envelope ms-1 text-white phara_16"></i></span>
                    </div>
                </div>
                <div class="d-flex justify-content-center">
                    <img src="../Assets/Images/profile-imges/companysignup.png" class="company_img" alt="w8" />
                </div>
            </div>
            <div class="col-lg-8 col-md-8 col-12 mt-lg-0 mt-md-0 mt-5 text-center ">
                <div class="d-flex justify-content-center">
                    <img src="../Assets/Images/profile-imges/job-search-company.png" alt="w8" />
                    <h3 class="Poppins">Medulla Effects</h3>
                </div>
                <div class="row mt-5 Halvetica">
                    <div class="col-12 text-center crd-row-one">
                        <h1 class="head_text">OTP Verification</h1>
                        <p class="pt-2 pb-2" style="font-weight: 400">
                            Lorem ipsum Lorem ipsum dolor sit amet consectetur adipisicing
                            elit. Omnis, asperiores. repudiandae a.
                        </p>
                    </div>

                </div>
                <form>
                    <div class="allotp">
                        <div class="div1">1</div>

                        <div class="div1">1</div>

                        <div class="div1">1</div>

                        <div class="div1">1</div>
                        <div class="div1">1</div>
                        <div class="div1">1</div>
                    </div>

                    <div class="mt-5">
                        <a href="./Sana/Questinare.html">
                            <button type="button" class="buttonfill Poppins phara_16">
                                Verify
                            </button></a>
                    </div>
                    <div class="pt-5">
                        <p class="Halvetica phara_16 mb-0" style="font-weight: 700">
                            Dont Recieve an email?
                            <span class="log_company"><a href="#">Resend</a></span>
                        </p>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

<head>
    @include('admin.assets.metatags')
    @include('admin.assets.css')
</head>

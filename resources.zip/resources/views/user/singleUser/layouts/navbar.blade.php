<!-- -----1st--Navbar--------- -->
<div class="container-fluid">
    <header>
        <nav class="d-flex ps-lg-5 pe-lg-5 ps-md-5 pe-md-5 ps-2 pe-2 p pt-4 pb-4 align-items-center">
            <div>
                <span><i class="ri-instagram-line just_colorhead start_16_respons"></i></span>
                <span>

                    <i class="ri-youtube-line ms-1 just_colorhead start_16_respons"></i>
                </span>
            </div>
            <div class="mx-auto land_page_head d-flex">
                <img src="{{ asset('user/images') }}/job-search-company.png" alt="w8" style="font-weight: 700;">
                <h4 class="just_colorhead Poppins">Medulla
                    Effects</h4>
            </div>
            <div>
                <span><i class="fa-solid fa-phone just_colorhead start_16_respons"></i></span>
                <span><i class="fa-regular fa-envelope ms-1 just_colorhead start_16_respons"></i></span>
            </div>
        </nav>
    </header>
</div>

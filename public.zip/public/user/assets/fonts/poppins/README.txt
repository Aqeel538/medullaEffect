A Pen created at CodePen.io. You can find this one at http://codepen.io/ZeroX-DG/pen/mAZqpp.

 this is my first ui design =)) hope you like it !